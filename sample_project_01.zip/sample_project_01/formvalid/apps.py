from django.apps import AppConfig


class FormvalidConfig(AppConfig):
    name = 'formvalid'
